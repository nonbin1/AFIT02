var swiperNestedsplash = new Swiper('.swiper-nestedsplash', {
scrollContainer:true,
mousewheelControl : true,
mode:'vertical',
//Enable Scrollbar
scrollbar: {
  container :'.swiper-scrollbarsplash',
  hide: true,
  draggable: false  
}
})
